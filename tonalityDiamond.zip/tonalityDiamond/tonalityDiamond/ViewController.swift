//
//  ViewController.swift
//  tonalityDiamond
//
//  Created by Jacob Richards on 2/22/17.
//  Copyright © 2017 Jacob Richards. All rights reserved.
//

import UIKit
import RtSwift

class SinOsc{
    var phase: Float = 0
    var freq: Float = 60
    var gain: Float = 1
    //every sound producing object has a method called tick that spits out val for a sample
    func tick() -> Float{
        //calc smaple
        let samp = sinf(self.phase*2*Float(M_PI))*gain
        
        phase += freq/Float(RtSwift.sampleRate)
        if phase > 1 {
            phase -= 1
        }
        return samp
    }
}

class SawOsc{
    var phase: Float = 0
    var freq: Float = 60
    var gain: Float = 1
    //every sound producing object has a method called tick that spits out val for a sample
    func tick() -> Float{
        //calc smaple
        let samp = 1-2*phase
        
        phase += freq/Float(RtSwift.sampleRate)
        if phase > 1 {
            phase -= 1
        }
        return samp*gain
    }
}

class SqrOsc{
    var phase: Float = 0
    var freq: Float = 60
    var gain: Float = 1
    //every sound producing object has a method called tick that spits out val for a sample
    func tick() -> Float{
        var samp: Float = 0.0
        
        if self.phase<0.5{
            samp = 1
        }
        else{
            samp = -1
        }
        
        phase += freq/Float(RtSwift.sampleRate)
        if phase > 1 {
            phase -= 1
        }
        return samp*gain
    }
}

class Envelope{
    var duration: Float = 0.1
    var value: Float //actual value of envelope rn
    
    enum State{
        case KEY_ON
        case KEY_OFF
    }
    var state = State.KEY_OFF
    
    init(duration: Float = 0.1){ //constructor
        self.duration = duration
        value = 0
    }
    func tick() -> Float{
        //should go from 0 to 1 in N samples.
        //multiply duration by sample rate to get number of samples
        let N = duration*Float(RtSwift.sampleRate)
        
        if state == State.KEY_ON{
            //count up to 1
            if value < 1{
                value += 1/N
            }
            //ensure we don't shoot past 1
            if value > 1{
                value = 1
            }
        }
        else if state == State.KEY_ON{
            if value > 0{
                value += 1/N
            }
            
            if value < 0{
                value = 0
            }
        }
        
        return value
    }
    
    func keyOn(){
        state = State.KEY_ON
    }
    
    func keyOff(){
        state = State.KEY_OFF
    }
}

class ADSR{
    var attack: Float, decay: Float, sustain: Float, release: Float
    var value: Float
    
    enum State{
        case OFF
        case ATTACK
        case DECAY
        case SUSTAIN
        case RELEASE
    }
    
    var state = State.OFF
    
    init(attack: Float = 0.1, decay: Float = 0.1,
         sustain: Float = 0.1, release: Float = 0.1){
        self.attack = attack
        self.decay = decay
        self.sustain = sustain
        self.release = release
        self.value = 0
    }
    
    func tick() -> Float{
        if state == State.ATTACK{
            //count from 0 to 1 in attack*Float(RtSwift.sampleRate) sample
            value += 1/(attack*Float(RtSwift.sampleRate))
            if value >= 1 {
                value = 1
                state = State.DECAY
            }
        }
        else if state == State.DECAY{
            //count down from 1 to sustain over decay*Float(RtSwift.sampleRate) sample
            value -= (1-sustain)/(decay*Float(RtSwift.sampleRate))
            if value <= sustain{
                value = sustain
                state = State.SUSTAIN
            }
        }
        else if state == State.SUSTAIN{
            //DO NOTHING
        }
        else if state == State.RELEASE{
            value -= sustain/(decay*Float(RtSwift.sampleRate))
            if value <= 0{
                state = State.OFF
            }
        }
        return value
    }
    
    func keyOn() {
        state = State.ATTACK
    }
    
    func keyOff() {
        state = State.RELEASE
    }
}

class Filter{
    //filter coeffs
    var b0: Float = 1, b1: Float = 0, b2: Float = 0
    var a0: Float = 1, a1: Float = 0, a2: Float = 0
    
    //Filter state (previous inputs/outputs)
    var x1: Float = 0, x2: Float = 0
    var y1: Float = 0, y2: Float = 0
    
    func tick(input: Float) -> Float{
        let y0 = (b0*input + b1*x1 + b2*x2 - a1*y1 - a2*y2)/a0
        
        //delayed inputs & outputs
        x2=x1
        x1=input
        y2=y1
        y1=y0
        return y0
    }
    
    func lowPass(cutoff: Float, Q: Float){
        let w0 = 2*Float(M_PI)*cutoff/Float(RtSwift.sampleRate)
        let alpha = sin(w0)/(2*Q)
        b0 =  (1 - cos(w0))/2
        b1 =   1 - cos(w0)
        b2 =  (1 - cos(w0))/2
        a0 =   1 + alpha
        a1 =  -2 * cos(w0)
        a2 =   1 - alpha
    }
}

class  SynthVoice {
    var osc = SinOsc()
    //var mod1 = SinOsc()
    //var filter = Filter()
    //var lfo = SinOsc()
    var env = ADSR(attack: 0.5, decay: 0.5, sustain: 0.5, release: 2)
    
    func tick() -> Float{
        return osc.tick()*env.tick()
    }
}

class ViewController: UIViewController {
    
    var voices: [SynthVoice] = []

    var multipliers: [Float] = [7/4,3/2,7/5,5/4,6/5,7/6,4/4,5/5,6/6,7/7,4/5,5/6,6/7,2/3,5/7,4/7]
    let fund: Float = 440.0
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for _ in 0..<16{
                    voices.append(SynthVoice())
        }
        // Do any additional setup after loading the view, typically from a nib.
        RtSwift.sampleRate = 44100
        
        
        RtSwift.start(process: {(left, right, numFrames) in
            for i in 0..<numFrames{
                
                var samp: Float = 0
                for i in 0..<16{
                    samp = samp + self.voices[i].tick()
                }
                //samp = self.voices[i].tick()
                //loop thru all synthvoices

                left[i] = samp
                right[i] = samp
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    //need array of oscs and envs
    @IBAction func on(sender: AnyObject) {
        guard let button = sender as? UIButton else {
            return
        }
        voices[button.tag].osc.freq = fund*multipliers[button.tag]
        print(button.tag, fund, multipliers[button.tag])
        voices[button.tag].env.keyOn()
        return
    }



    @IBAction func off(sender: AnyObject) {
        guard let button = sender as? UIButton else {
            return
        }
        voices[button.tag].env.keyOff()
        return
    }




}

